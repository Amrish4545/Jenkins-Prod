# Script Usage Guide

This document explains how to use the provided Bash script to automate tasks in Jenkins.

## Prerequisites

1. Ensure you have access to the Jenkins home directory.
2. Verify that the following files and folders are present in the Jenkins home directory:
   - `jobs/`
   - `config.xml`
   - `jenkins_user.txt`
   - `users/`

## Steps to Run the Script

Follow these steps to run the script successfully:

1. **Copy the Script**  
   Move the Bash script (`rename-userdomainmail.sh`) to the Jenkins home directory:
   ```bash
   cp rename-userdomainmail.sh /path/to/jenkins_home/
   bash rename-userdomaimail.sh 
